<!-- Header Section -->
 <link rel="stylesheet" href="web.css">
<div class="header">
    <div class="container">
      <div class="navbar">
        <div class="logo">
          <a href="index.html"><img src="https://i.ibb.co/kDVwgwp/logo.png" alt="RedStore" width="125px" /></a>
        </div>
        <nav>
          <ul id="MenuItems">
            <li><a href="index.html">Home</a></li>
            <li><a href="product.html">Products</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">Contact</a></li>
            <li><a href="account.html">Account</a></li>
          </ul>
        </nav>
        <a href="cart.html"><img src="https://i.ibb.co/PNjjx3y/cart.png" alt="" width="30px" height="30px" /></a>
        <img src="https://i.ibb.co/6XbqwjD/menu.png" alt="" class="menu-icon" onclick="menutoggle()" />
      </div>
      <div class="row">
        <div class="col-2">
          <h1>
            Give Your Workout <br />
            A New Style!
          </h1>
          <p>
            Success isn't always about greatness. It's about consistency.
            Consistent <br />hard work gains success. Greatness will come.
          </p>
          <a href="#" target="_blank" rel="noopener noreferrer" class="btn">Explore Now →</a>
        </div>
        <div class="col-2">
          <img src="https://i.ibb.co/QpTmdX5/image1.png" alt="" />
        </div>
      </div>
    </div>
  </div>
  <!-- Featured categories -->
<div class="categories">
  <div class="small-container">
    <div class="row">
      <div class="col-3">
        <img src="https://i.ibb.co/sqnY1pG/category-1.jpg" alt="" />
      </div>
      <div class="col-3">
        <img src="https://i.ibb.co/GCJLQRQ/category-2.jpg" alt="" />
      </div>
      <div class="col-3">
        <img src="https://i.ibb.co/wYsXqP5/category-3.jpg" alt="" />
      </div>
    </div>
  </div>
</div>

<!-- Featured products -->
 <link rel="stylesheet" href="web1.css">
<div class="small-container">
  <h2 class="title">Featured Products</h2>
  <div class="row">
    <div class="col-4">
      <a href="product_details.html"><img src="https://i.ibb.co/47Sk9QL/product-1.jpg" alt="" /></a>
      <a href="product_details.html">
        <h4>Red Printed T-shirt</h4>
      </a>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
    </div>
    <div class="col-4">
      <img src="https://i.ibb.co/KsMVr26/product-3.jpg" alt="" />
	      <a href="product_details.html">
      <h4>smoke gray joggers</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i>
      </div>
      <p>₹500.00</p>
    </div>

    <div class="col-4">
      <img src="https://i.ibb.co/0cMfpcr/product-4.jpg" alt="" />
      <h4>navy blue puma T-shirt</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
    </div>
  </div>
  <h2 class="title">Latest Products</h2>
  <div class="row">
    <div class="col-4">
      <img src="https://i.ibb.co/bQ5t8bR/product-5.jpg" alt="" />
      <h4>gray sports shoes</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
    </div>

    <div class="col-4">
      <img src="https://i.ibb.co/vVpTyBD/product-6.jpg" alt="" />
      <h4>black stripped puma t-shirt</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
    </div>

    <div class="col-4">
      <img src="https://i.ibb.co/hR5FGwH/product-7.jpg" alt="" />
      <h4>3-pair of socks</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i>
      </div>
      <p>₹500.00</p>
    </div>

    <div class="col-4">
      <img src="https://i.ibb.co/QfCgdXZ/product-8.jpg" alt="" />
      <h4>Fossil black chain watch</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
    </div>
  </div>

  <div class="row">
    <div class="col-4">
      <img src="https://i.ibb.co/nw5xZwk/product-9.jpg" alt="" />
      <h4>roadster black belt watch</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
    </div>

    <div class="col-4">
      <img src="https://i.ibb.co/9HCsmjf/product-10.jpg" alt="" />
      <h4>HRX black shoes</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
    </div>

    <div class="col-4">
      <img src="https://i.ibb.co/JQ2MBHR/product-11.jpg" alt="" />
      <h4>Roadster gray shoes</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="fas fa-star-half-alt"></i>
      </div>
      <p>₹500.00</p>
    </div>

    <div class="col-4">
      <img src="https://i.ibb.co/nRZMs6Y/product-12.jpg" alt="" />
      <h4>Nike black trousers</h4>
      <div class="rating">
        <i class="fas fa-star"></i>
        <i class="fas fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
        <i class="far fa-star"></i>
      </div>
      <p>₹500.00</p>
    </div>
  </div>
</div>
<!-- offer -->
<div class="offer">
  <div class="small-container">
    <div class="row">
      <div class="col-2">
        <img src="https://i.ibb.co/HF5TncZ/exclusive.png" alt="" class="offer-img" />
      </div>
      <div class="col-2">
        <p>Exclusively Available on RedStore</p>
        <h1>Smart Band 4</h1>
        <small>The Mi Smart Band 4 features a 39.9% larger (than Mi Band 3)
          AMOLED color full-touch display with adjustable brightness, so
          everything is clear as can be.</small>
        <br />
        <a href="#" class="btn">Buy Now →</a>
      </div>
    </div>
  </div>
</div>


<!-- brands -->
<div class="brands">
  <div class="small-container">
    <div class="row">
      <div class="col-5">
        <img src="https://i.ibb.co/Gfwzz1S/logo-godrej.png" alt="" />
      </div>

      <div class="col-5">
        <img src="https://i.ibb.co/vjrRZFM/logo-oppo.png" alt="" />
      </div>

      <div class="col-5">
        <img src="https://i.ibb.co/3zs234S/logo-coca-cola.png" alt="" />
      </div>

      <div class="col-5">
        <img src="https://i.ibb.co/7Wt343W/logo-paypal.png" alt="" />
      </div>

      <div class="col-5">
        <img src="https://i.ibb.co/GVSNwJD/logo-philips.png" alt="" />
      </div>
    </div>
  </div>
</div>
 <link rel="stylesheet" href="foot.css">
<div class="footer">
    <div class="container">
      <div class="row">
        <div class="footer-col-1">
          <h3>Download Our App</h3>
          <p>Download App for Android and iso mobile phone.</p>
          <div class="app-logo">
            <img src="https://i.ibb.co/KbPTYYQ/play-store.png" alt="" />
            <img src="https://i.ibb.co/hVM4X2p/app-store.png" alt="" />
          </div>
        </div>

        <div class="footer-col-2">
          <img src="https://i.ibb.co/j3FNGj7/logo-white.png" alt="" />
          <p>
            Our Purpose Is To Sustainably Make the Pleasure and Benefits of
            Sports Accessible to the Many.
          </p>
        </div>

        <div class="footer-col-3">
          <h3>Useful Links</h3>
          <ul>
            <li>Coupons</li>
            <li>Blog Post</li>
            <li>Return Policy</li>
            <li>Join Affiliate</li>
          </ul>
        </div>

        <div class="footer-col-4">
          <h3>Follow us</h3>
          <ul>
            <li>Facebook</li>
            <li>Twitter</li>
            <li>Instagram</li>
            <li>YouTube</li>
          </ul>
        </div>
      </div>
      <hr />
      <p class="copyright">Copyright &copy; 2021 - Red Store</p>
    </div>
  </div>
  <script
  var MenuItems = document.getElementById('MenuItems');
MenuItems.style.maxHeight = '0px';

function menutoggle() {
  if (MenuItems.style.maxHeight == '0px') {
    MenuItems.style.maxHeight = '200px';
  } else {
    MenuItems.style.maxHeight = '0px';
  }
}
>
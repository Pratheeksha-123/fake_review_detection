document.addEventListener("DOMContentLoaded", () => {
    const getReviewsButton = document.getElementById("getReviews");
    const asinInput = document.getElementById("asin");
    const reviewsContainer = document.getElementById("reviewsContainer");

    getReviewsButton.addEventListener("click", () => {
        const asin = asinInput.value.trim();
        if (asin === "") return;

        // Replace with your backend endpoint that handles the API request
        const endpoint = `/api/get-reviews?asin=${asin}`;

        fetch(endpoint)
            .then(response => response.json())
            .then(data => {
                reviewsContainer.innerHTML = "";
                data.reviews.forEach(review => {
                    const reviewElement = document.createElement("div");
                    reviewElement.classList.add("review");
                    reviewElement.textContent = review.reviewText;
                    reviewsContainer.appendChild(reviewElement);
                });
            })
            .catch(error => {
                console.error("Error fetching reviews:", error);
            });
    });
});
<!DOCTYPE html>
<html>
<head>
    <title>Review Form</title>
    <style>
        .rate {
    float: left;
    height: 46px;
    padding: 0 10px;
}
.rate:not(:checked) > input {
    position:absolute;
    top:-9999px;
}
.rate:not(:checked) > label {
    float:right;
    width:1em;
    overflow:hidden;
    white-space:nowrap;
    cursor:pointer;
    font-size:30px;
    color:#ccc;
}
.rate:not(:checked) > label:before {
    content: '★ ';
}
.rate > input:checked ~ label {
    color: #ffc700;    
}
.rate:not(:checked) > label:hover,
.rate:not(:checked) > label:hover ~ label {
    color: #deb217;  
}
.rate > input:checked + label:hover,
.rate > input:checked + label:hover ~ label,
.rate > input:checked ~ label:hover,
.rate > input:checked ~ label:hover ~ label,
.rate > label:hover ~ input:checked ~ label {
    color: #c59b08;
}
 .btn {
    display: inline-block;
    background: #ff523b;
    color: #ffffff;
    padding: 8px 30px;
    margin: 30px 0;
    border-radius: 30px;
    transition: background 0.5s;
  }
  
  .btn:hover {
    background: #563434;
  }
        
    </style>
</head>
<body>
    <h1>Submit a Review</h1>
    <form>
	  <table>
	    <td>
            <tr><label for="category">Category:</label></tr>
            <input type="text" id="category" name="category" required></tr>
        </td>
		<br>
	    <td>
             <tr><label for="review">Review:</label>
             <textarea id="review" name="text" rows="4" required></textarea>
		     </tr>
	    </td>
		<br>
		<td>

			<tr>
				<div class="rate">
				<input type="radio" id="star5" name="rating" value="5" />
				<label for="star5" title="text">5 stars</label>
				<input type="radio" id="star4" name="rating" value="4" />
				<label for="star4" title="text">4 stars</label>
				<input type="radio" id="star3" name="rating" value="3" />
				<label for="star3" title="text">3 stars</label>
				<input type="radio" id="star2" name="rating" value="2" />
				<label for="star2" title="text">2 stars</label>
				<input type="radio" id="star1" name="rating" value="1" />
				<label for="star1" title="text">1 star</label>
				</div>
			</tr>
			</td>
			<br>
			<td>
		<a href="insert1.php" target="_blank" rel="noopener noreferrer" class="btn">submit</a>
		</td>
		</table>
    </form>
</body>
</html>